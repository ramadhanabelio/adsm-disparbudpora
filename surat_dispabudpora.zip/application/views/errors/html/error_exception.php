<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Exception Occurred</title>
</head>

<body>
    <h1>An Exception Was Encountered</h1>
    <p><?= isset($message) ? $message : 'An unknown exception occurred.' ?></p>
</body>

</html>