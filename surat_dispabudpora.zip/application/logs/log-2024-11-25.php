<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-25 03:27:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'surat_dispabudpora' C:\xampp\htdocs\surat_dispabudpora\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-11-25 03:27:34 --> Unable to connect to the database
ERROR - 2024-11-25 03:27:34 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:27:34 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:27:49 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-25 03:27:49 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:27:49 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:27:51 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-25 03:27:51 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:27:51 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:28:11 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-25 03:28:11 --> Severity: Warning --> include(C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:28:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:28:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\surat_disparbudpora\application\views\user\index.php 36
ERROR - 2024-11-25 03:28:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\surat_disparbudpora\application\views\user\index.php 38
ERROR - 2024-11-25 03:29:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\surat_disparbudpora\application\views\user\index.php 36
ERROR - 2024-11-25 03:29:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\surat_disparbudpora\application\views\user\index.php 38
ERROR - 2024-11-25 03:29:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\surat_disparbudpora\application\views\user\index.php 36
ERROR - 2024-11-25 03:29:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\surat_disparbudpora\application\views\user\index.php 38
ERROR - 2024-11-25 03:40:07 --> Query error: Unknown column 'id_unit' in 'field list' - Invalid query: INSERT INTO `tb_disposisi` (`id_suratmasuk`, `id_unit`, `id_jabatan`, `keterangan`, `status`) VALUES ('3', '7', '19', NULL, 'pending')
ERROR - 2024-11-25 03:40:07 --> Severity: Warning --> include(C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:40:07 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:46:34 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-25 03:46:34 --> Severity: Warning --> include(C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:46:34 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:47:26 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-25 03:47:26 --> Severity: Warning --> include(C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:47:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:47:34 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-25 03:47:34 --> Severity: Warning --> include(C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:47:34 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:48:01 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-25 03:48:01 --> Severity: Warning --> include(C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
ERROR - 2024-11-25 03:48:01 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_disparbudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_disparbudpora\system\core\Exceptions.php 183
