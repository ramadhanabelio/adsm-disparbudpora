<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-22 02:55:46 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 02:55:46 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 02:55:46 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:08:40 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 03:08:40 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:08:40 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:12:46 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 03:12:46 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:12:46 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:13:10 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 03:13:10 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:13:10 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:16:47 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 03:16:47 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:16:47 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:16:58 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 03:16:58 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:16:58 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:17:05 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 03:17:05 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:17:05 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:17:31 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 03:17:31 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 03:17:31 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 04:13:59 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 04:13:59 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 04:13:59 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 05:47:57 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 05:47:57 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 05:47:57 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 05:48:12 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 05:48:12 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 05:48:12 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 05:48:41 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 05:48:41 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 05:48:41 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 05:49:57 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-22 05:49:57 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-22 05:49:57 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
