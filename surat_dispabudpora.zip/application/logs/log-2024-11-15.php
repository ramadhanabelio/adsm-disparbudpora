<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-15 08:22:23 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:22:23 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:22:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:01 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:23:01 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:01 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:08 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:23:08 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:08 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:19 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:23:19 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:32 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:23:32 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:32 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:38 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:23:38 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:38 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:48 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:23:48 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:23:48 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:25:09 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:25:09 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:25:09 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:25:23 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:25:23 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:25:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:25:35 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:25:35 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:25:35 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:25:43 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:25:43 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:25:43 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:26:41 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:26:41 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:26:41 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:28:18 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:28:18 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:28:18 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:29:08 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:29:08 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:29:08 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:39:16 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:39:16 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:39:16 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:40:47 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:40:47 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:40:47 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:41:05 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:41:05 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:41:05 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:41:22 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:41:22 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:41:22 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:41:32 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:41:32 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:41:32 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:46:43 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:46:43 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:46:43 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:47:57 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-15 08:47:57 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-15 08:47:57 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
