<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-17 08:57:10 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2024-11-17 08:57:10 --> Severity: Warning --> include(C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
ERROR - 2024-11-17 08:57:10 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\surat_dispabudpora\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_dispabudpora\system\core\Exceptions.php 183
